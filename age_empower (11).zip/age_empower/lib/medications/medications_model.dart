import '/auth/base_auth_user_provider.dart';
import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/index.dart';
import 'medications_widget.dart' show MedicationsWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MedicationsModel extends FlutterFlowModel<MedicationsWidget> {
  ///  Local state fields for this page.

  int? editingIndex = -1;

  String? searchText = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
