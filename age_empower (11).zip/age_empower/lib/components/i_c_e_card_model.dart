import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'i_c_e_card_widget.dart' show ICECardWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class ICECardModel extends FlutterFlowModel<ICECardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
