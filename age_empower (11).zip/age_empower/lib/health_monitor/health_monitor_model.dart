import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'health_monitor_widget.dart' show HealthMonitorWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HealthMonitorModel extends FlutterFlowModel<HealthMonitorWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
