import '/components/i_c_e_card_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import 'emergency_widget.dart' show EmergencyWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class EmergencyModel extends FlutterFlowModel<EmergencyWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for ICECard component.
  late ICECardModel iCECardModel;

  @override
  void initState(BuildContext context) {
    iCECardModel = createModel(context, () => ICECardModel());
  }

  @override
  void dispose() {
    iCECardModel.dispose();
  }
}
